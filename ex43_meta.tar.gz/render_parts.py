import os; os.environ['PYOPENGL_PLATFORM']='egl'
import numpy as np, trimesh, pyrender, glob, sys
from PIL import Image
def look_at(eye,tgt,up):
    f=tgt-eye; f=f/np.linalg.norm(f); s=np.cross(f,up); s=s/np.linalg.norm(s); u=np.cross(s,f)
    M=np.eye(4); M[:3,0]=s; M[:3,1]=u; M[:3,2]=-f; M[:3,3]=eye; return M
def render_glb(path,outp,azs=(40,-40),el=18,res=560):
    tm=trimesh.load(path,force='scene'); geoms=tm.dump() if isinstance(tm,trimesh.Scene) else [tm]
    allv=np.vstack([g.vertices for g in geoms]); c=np.median(allv,axis=0)
    r=np.percentile(np.linalg.norm(allv-c,axis=1),93)
    ext=np.percentile(allv,97,axis=0)-np.percentile(allv,3,axis=0); up_idx=int(np.argmax(ext))
    up=np.zeros(3); up[up_idx]=1; ax=[0,1,2]; ax.remove(up_idx)
    a0=np.zeros(3);a0[ax[0]]=1; a1=np.zeros(3);a1[ax[1]]=1; yfov=np.pi/4.2
    for az in azs:
        sc=pyrender.Scene(bg_color=[245,245,245,255],ambient_light=[0.55,0.55,0.55])
        for g in geoms: sc.add(pyrender.Mesh.from_trimesh(g,smooth=False))
        ar=np.radians(az); er=np.radians(el); horiz=np.cos(ar)*a0+np.sin(ar)*a1; d=np.cos(er)*horiz+np.sin(er)*up
        dist=r/np.sin(yfov/2)*1.15; eye=c+dist*d
        sc.add(pyrender.PerspectiveCamera(yfov=yfov),pose=look_at(eye,c,up))
        for ld in [d,up-d*0.3,np.cross(d,up)]:
            ldn=ld/np.linalg.norm(ld); sc.add(pyrender.DirectionalLight(color=[1,1,1],intensity=3.2),pose=look_at(c+r*4*ldn,c,up))
        rr=pyrender.OffscreenRenderer(res,res); col,_=rr.render(sc); rr.delete()
        Image.fromarray(col).save(f"{outp}_{'L' if az>0 else 'R'}.png")
if __name__=="__main__":
    C="/liuhaohan/work/single_image_tests/tex_exp"; OUT=C+"/renders"; os.makedirs(OUT,exist_ok=True)
    fs=sorted(glob.glob(C+"/colored/*.glb")) if len(sys.argv)<2 else [sys.argv[1]]
    for f in fs:
        name=os.path.basename(f)[:-4]
        try: render_glb(f,f"{OUT}/{name}"); print("OK",name)
        except Exception as e: print("ERR",name,repr(e))
