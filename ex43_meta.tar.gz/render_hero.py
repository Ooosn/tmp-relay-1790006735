import os; os.environ['PYOPENGL_PLATFORM']='egl'
import numpy as np, trimesh, pyrender, glob, sys
from PIL import Image
C="/liuhaohan/work/single_image_tests/tex_exp"
PAL=[(107,201,222),(240,175,90),(242,133,105),(88,196,165),(170,214,110),(233,120,175),(190,140,205),(130,190,232),(238,205,130),(160,224,205),(120,130,205),(224,150,95),(96,205,225),(210,170,225)]
def parts_for(m,i):
    if m=="partcrafter": return sorted(glob.glob(f"{C}/partcrafter/results/{i}/part_*.glb"))
    if m=="spark": return sorted(glob.glob(f"{C}/spark/{i}/inference/FT5_G1_0/part_*_cleaned.glb"))
    if m=="xpart":
        p=f"{C}/xpart/{i}/xpart/xpart_parts.glb"; return [p] if os.path.exists(p) else []
    if m=="omnipart":
        p=f"{C}/omnipart/{i}/combined_parts.glb"; return [p] if os.path.exists(p) else []
    if m=="ours": return glob.glob(f"{C}/ours/{i}/mesh_parts_with_axes_*.glb")[:1]
    return []
def load_parts(m,i):
    ms=[]
    for f in parts_for(m,i):
        s=trimesh.load(f,force='scene')
        for g in (s.dump() if isinstance(s,trimesh.Scene) else [s]):
            if hasattr(g,'vertices') and len(g.vertices)>0: ms.append(g)
    if m=="ours" and len(ms)>1:
        mx=max(len(x.vertices) for x in ms); ms=[x for x in ms if len(x.vertices)>max(80,0.03*mx)]
    return ms
def look_at(eye,t,up):
    f=t-eye;f=f/np.linalg.norm(f);s=np.cross(f,up);s=s/np.linalg.norm(s);u=np.cross(s,f)
    M=np.eye(4);M[:3,0]=s;M[:3,1]=u;M[:3,2]=-f;M[:3,3]=eye;return M
def render(m,i,mode,out,res=780,az=40,el=22):
    ms=load_parts(m,i)
    if not ms: print("no parts",m,i); return
    ms=[x.copy() for x in ms]
    allv=np.vstack([x.vertices for x in ms]);c=np.median(allv,0)
    ext=np.percentile(allv,97,0)-np.percentile(allv,3,0);ui=int(np.argmax(ext))
    R=np.percentile(np.linalg.norm(allv-c,1),93)
    if mode=="exploded":
        for x in ms:
            pc=x.vertices.mean(0);dv=pc-c
            if np.linalg.norm(dv)<1e-6*R+1e-9: dv=np.random.randn(3)
            dv=dv/np.linalg.norm(dv); x.vertices=x.vertices+dv*R*0.55
    for k,x in enumerate(ms):
        col=PAL[k%len(PAL)];x.visual=trimesh.visual.ColorVisuals(mesh=x,vertex_colors=np.tile(np.array(col+(255,),np.uint8),(len(x.vertices),1)))
    allv=np.vstack([x.vertices for x in ms]);c=np.median(allv,0);R=np.percentile(np.linalg.norm(allv-c,1),93)
    up=np.zeros(3);up[ui]=1;ax=[0,1,2];ax.remove(ui);a0=np.zeros(3);a0[ax[0]]=1;a1=np.zeros(3);a1[ax[1]]=1
    ymin=allv[:,ui].min()
    sc=pyrender.Scene(bg_color=[255,255,255,255],ambient_light=[0.62,0.62,0.62])
    for x in ms: sc.add(pyrender.Mesh.from_trimesh(x,smooth=False))
    e3=[R*7,R*7,R*7];e3[ui]=R*0.02
    g=trimesh.creation.box(extents=e3);gc=c.copy();gc[ui]=ymin-R*0.011;g.apply_translation(gc-g.bounds.mean(0))
    g.visual=trimesh.visual.ColorVisuals(mesh=g,vertex_colors=np.tile(np.array([245,245,245,255],np.uint8),(len(g.vertices),1)))
    pass  # no ground
    yfov=np.pi/4.6;ar=np.radians(az);er=np.radians(el)
    d=np.cos(er)*(np.cos(ar)*a0+np.sin(ar)*a1)+np.sin(er)*up
    dist=R/np.sin(yfov/2)*1.3;eye=c+dist*d
    sc.add(pyrender.PerspectiveCamera(yfov=yfov),pose=look_at(eye,c,up))
    kl=up*1.0+0.32*a0+0.12*a1
    sc.add(pyrender.DirectionalLight(color=[1,1,1],intensity=3.6),pose=look_at(c+R*6*kl/np.linalg.norm(kl),c,up))
    sc.add(pyrender.DirectionalLight(color=[1,1,1],intensity=1.1),pose=look_at(eye,c,up))
    r=pyrender.OffscreenRenderer(res,res)
    col,_=r.render(sc);r.delete()
    Image.fromarray(col).save(out); print("OK",m,i,mode,"parts",len(ms))
if __name__=="__main__":
    a=sys.argv; render(a[1],a[2],a[3],a[4])
