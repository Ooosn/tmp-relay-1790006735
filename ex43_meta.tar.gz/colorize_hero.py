import trimesh, numpy as np, glob, os, sys
C="/liuhaohan/work/single_image_tests/tex_exp"; OUT=C+"/colored_hero"; os.makedirs(OUT,exist_ok=True)
PAL=[(107,201,222),(240,175,90),(242,133,105),(88,196,165),(170,214,110),(233,120,175),(190,140,205),(130,190,232),(238,205,130),(160,224,205),(120,130,205),(224,150,95),(96,205,225),(210,170,225)]
def parts_for(m,i):
    if m=="partcrafter": return sorted(glob.glob(f"{C}/partcrafter/results/{i}/part_*.glb"))
    if m=="spark": return sorted(glob.glob(f"{C}/spark/{i}/inference/FT5_G1_0/part_*_cleaned.glb"))
    if m=="xpart":
        p=f"{C}/xpart/{i}/xpart/xpart_parts.glb"; return [p] if os.path.exists(p) else []
    if m=="omnipart":
        p=f"{C}/omnipart/{i}/combined_parts.glb"; return [p] if os.path.exists(p) else []
    if m=="ours": return glob.glob(f"{C}/ours/{i}/mesh_parts_with_axes_*.glb")[:1]
    return []
def load_parts(m,i):
    ms=[]
    for f in parts_for(m,i):
        s=trimesh.load(f,force='scene')
        for g in (s.dump() if isinstance(s,trimesh.Scene) else [s]):
            if hasattr(g,'vertices') and len(g.vertices)>0: ms.append(g)
    if m=="ours" and len(ms)>1:
        mx=max(len(x.vertices) for x in ms); ms=[x for x in ms if len(x.vertices)>max(80,0.03*mx)]
    return ms
def col(mm):
    for k,x in enumerate(mm):
        c=PAL[k%len(PAL)]; x.visual=trimesh.visual.ColorVisuals(mesh=x,vertex_colors=np.tile(np.array(c+(255,),np.uint8),(len(x.vertices),1)))
def build(m,i):
    ms=load_parts(m,i)
    if not ms: print("SKIP",m,i); return
    ms=[x.copy() for x in ms]
    allv=np.vstack([x.vertices for x in ms]); c=np.median(allv,0); lo=np.percentile(allv,2,0);hi=np.percentile(allv,98,0);R=0.5*np.linalg.norm(hi-lo)
    whole=[x.copy() for x in ms]; col(whole); trimesh.Scene(whole).export(f"{OUT}/{m}_{i}_whole.glb")
    exp=[x.copy() for x in ms]
    for x in exp:
        pc=np.median(x.vertices,0); dv=pc-c
        if np.linalg.norm(dv)<1e-6*R+1e-9: dv=np.random.randn(3)
        dv=dv/np.linalg.norm(dv); x.vertices=x.vertices+dv*R*0.55
    col(exp); trimesh.Scene(exp).export(f"{OUT}/{m}_{i}_exploded.glb")
    print("OK",m,i,"parts",len(ms))
if __name__=="__main__": build(sys.argv[1],sys.argv[2])
