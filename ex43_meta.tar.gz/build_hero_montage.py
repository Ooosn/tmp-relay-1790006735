from PIL import Image,ImageDraw,ImageFont
import os,sys
C="/liuhaohan/work/single_image_tests/tex_exp"; R=C+"/renders"; IN=C+"/input"
ids=[("100776","suitcase"),("102209","trash bin"),("11846","refrigerator"),("7128","microwave")]
methods=[("partcrafter","PartCrafter"),("omnipart","OmniPart"),("spark","SPARK"),("xpart","TRELLIS.2+P3-SAM+X-Part"),("ours","Ours")]
def font(s):
    for p in ["/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf","/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"]:
        try: return ImageFont.truetype(p,s)
        except: pass
    return ImageFont.load_default()
fb=font(20)
def build(mode,outname):
    cell=380;hdr=46;lm=44;cols=1+len(methods);W=lm+cols*cell;H=hdr+len(ids)*cell
    sh=Image.new('RGB',(W,H),(255,255,255));d=ImageDraw.Draw(sh)
    def ct(t,cx,w,y,col=(15,15,15)):
        tw=d.textlength(t,font=fb);d.text((cx+(w-tw)/2,y),t,fill=col,font=fb)
    ct("Input",lm,cell,14);cx=lm+cell
    for mk,mn in methods: ct(mn,cx,cell,14);cx+=cell
    def place(p,cx,cy):
        if os.path.exists(p): sh.paste(Image.open(p).convert('RGB').resize((cell,cell)),(cx,cy))
        else: d.rectangle([cx,cy,cx+cell-1,cy+cell-1],fill=(235,235,235))
    for r,(i,nm) in enumerate(ids):
        y=hdr+r*cell; place(f"{IN}/{i}.jpg",lm,y);cx=lm+cell
        for mk,mn in methods: place(f"{R}/{mk}_{i}_{mode}_L.png",cx,y);cx+=cell
    sh.save(C+"/"+outname);print(outname,sh.size)
build("whole","montage_whole.png"); build("exploded","montage_exploded.png")
