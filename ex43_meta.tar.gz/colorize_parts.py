import trimesh, numpy as np, glob, os, sys
C="/liuhaohan/work/single_image_tests/tex_exp"; OUT=C+"/colored"; os.makedirs(OUT,exist_ok=True)
PAL=[(230,25,75),(60,180,75),(0,130,200),(245,130,48),(145,30,180),(70,240,240),(240,50,230),(210,245,60),(0,128,128),(230,190,255),(170,110,40),(128,0,0),(170,255,195),(128,128,0),(0,0,128),(128,128,128),(250,190,190),(255,215,180),(255,250,200),(60,60,60)]
def parts_for(m,i):
    if m=="partcrafter": return sorted(glob.glob(f"{C}/partcrafter/results/{i}/part_*.glb"))
    if m=="spark": return sorted(glob.glob(f"{C}/spark/{i}/inference/FT5_G1_0/part_*_cleaned.glb"))
    if m=="xpart":
        p=f"{C}/xpart/{i}/xpart/xpart_parts.glb"; return [p] if os.path.exists(p) else []
    if m=="omnipart":
        for n in ["combined_parts.glb","exploded_parts.glb"]:
            p=f"{C}/omnipart/{i}/{n}";
            if os.path.exists(p): return [p]
        return []
    if m=="ours": return glob.glob(f"{C}/ours/{i}/mesh_parts_with_axes_*.glb")[:1]
    return []
def load_meshes(files,drop=False):
    ms=[]
    for f in files:
        s=trimesh.load(f,force='scene')
        for g in (s.dump() if isinstance(s,trimesh.Scene) else [s]):
            if hasattr(g,'vertices') and len(g.vertices)>0: ms.append(g)
    if drop and len(ms)>1:
        mx=max(len(m.vertices) for m in ms); ms=[m for m in ms if len(m.vertices)>max(80,0.03*mx)]
    return ms
def colorize(m,i):
    fs=parts_for(m,i)
    if not fs: print("SKIP",m,i,"nofiles"); return
    ms=load_meshes(fs,drop=(m=="ours"))
    if not ms: print("SKIP",m,i,"nomesh"); return
    for k,mesh in enumerate(ms):
        c=PAL[k%len(PAL)]; mesh.visual=trimesh.visual.ColorVisuals(mesh=mesh,vertex_colors=np.tile(np.array(c+(255,),np.uint8),(len(mesh.vertices),1)))
    op=f"{OUT}/{m}_{i}.glb"; trimesh.Scene(ms).export(op); print("OK",m,i,"parts",len(ms),os.path.getsize(op))
if __name__=="__main__":
    colorize(sys.argv[1],sys.argv[2])
