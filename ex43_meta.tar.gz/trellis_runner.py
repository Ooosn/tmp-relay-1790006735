import os, time
os.environ.setdefault('ATTN_BACKEND','xformers'); os.environ['OPENCV_IO_ENABLE_OPENEXR']='1'; os.environ['PYTORCH_CUDA_ALLOC_CONF']='expandable_segments:True'
import torch
from PIL import Image
from trellis2.pipelines import Trellis2ImageTo3DPipeline
import o_voxel
IN="/liuhaohan/work/single_image_tests/tex_exp/input"; OUT="/liuhaohan/work/single_image_tests/tex_exp/trellis2"; os.makedirs(OUT,exist_ok=True)
ids=["100776","102209","11846","7128"]
print("== loading ==",flush=True); t=time.time()
pipe=Trellis2ImageTo3DPipeline.from_pretrained("/liuhaohan/models/TRELLIS.2-4B"); pipe.cuda(); print("loaded %.1fs"%(time.time()-t),flush=True)
for i in ids:
    outp=os.path.join(OUT,i+".glb")
    if os.path.exists(outp): print("skip",i,flush=True); continue
    try:
        print("== run",i,flush=True); t=time.time()
        im=Image.open(os.path.join(IN,i+".jpg")).convert("RGB")
        mesh=pipe.run(im)[0]; mesh.simplify(16777216)
        glb=o_voxel.postprocess.to_glb(vertices=mesh.vertices,faces=mesh.faces,attr_volume=mesh.attrs,coords=mesh.coords,attr_layout=mesh.layout,voxel_size=mesh.voxel_size,aabb=[[-0.5,-0.5,-0.5],[0.5,0.5,0.5]],decimation_target=200000,texture_size=1024,remesh=False,remesh_band=1,remesh_project=0,verbose=True)
        glb.export(outp,extension_webp=True); print("OK",i,os.path.getsize(outp),"%.1fs"%(time.time()-t),flush=True)
    except Exception as e:
        print("ERR",i,repr(e),flush=True)
print("TRELLIS_TEX_DONE",flush=True)
