from PIL import Image,ImageDraw,ImageFont
import os
C="/liuhaohan/work/single_image_tests/tex_exp"; R=C+"/renders"; IN=C+"/input"
ids=["100776","102209","11846","7128"]; nm={"100776":"suitcase","102209":"trash bin","11846":"refrigerator","7128":"microwave"}
methods=[("partcrafter","PartCrafter"),("omnipart","OmniPart"),("spark","SPARK"),("xpart","TRELLIS.2+P3-SAM+X-Part"),("ours","Ours")]
cell=300; hdr=46; lm=44
cols=1+len(methods)*2; W=lm+cols*cell; H=hdr+len(ids)*cell
sh=Image.new('RGB',(W,H),(255,255,255)); d=ImageDraw.Draw(sh)
def font(s):
    for p in ["/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf","/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"]:
        try: return ImageFont.truetype(p,s)
        except: pass
    return ImageFont.load_default()
fb=font(19); fs=font(15)
def ctext(txt,cx,w,y,f,col=(15,15,15)):
    tw=d.textlength(txt,font=f); d.text((cx+(w-tw)/2,y),txt,fill=col,font=f)
ctext("Input",lm,cell,14,fb)
cx=lm+cell
for mk,mn in methods:
    ctext(mn,cx,cell*2,14,fb); cx+=cell*2
def place(p,cx,cy):
    if os.path.exists(p):
        sh.paste(Image.open(p).convert('RGB').resize((cell,cell)),(cx,cy))
    else:
        d.rectangle([cx,cy,cx+cell-1,cy+cell-1],fill=(232,232,232)); ctext("(pending)",cx,cell,cy+cell//2,fs,(150,150,150))
for r,i in enumerate(ids):
    y=hdr+r*cell
    ip=f"{IN}/{i}.jpg"; place(ip,lm,y)
    cx=lm+cell
    for mk,mn in methods:
        for v in ["L","R"]: place(f"{R}/{mk}_{i}_{v}.png",cx,y); cx+=cell
sh.save(C+"/montage_ex43.png"); print("montage",sh.size)
