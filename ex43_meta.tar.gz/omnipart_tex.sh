#!/bin/bash
C=/liuhaohan/work/single_image_tests/tex_exp
exec >> $C/omnipart_tex.log 2>&1
echo "===== OMNIPART $(date) ====="
for i in $(seq 1 500); do grep -q OURS_TEX_DONE $C/ours_tex.log 2>/dev/null && break; sleep 30; done
source /liuhaohan/miniconda3/etc/profile.d/conda.sh; conda activate omnipart
cd /liuhaohan/repos/OmniPart
export CUDA_VISIBLE_DEVICES=0 OPENCV_IO_ENABLE_OPENEXR=1 SPCONV_ALGO=native HF_HOME=/liuhaohan/.cache/huggingface
PY=/liuhaohan/miniconda3/envs/omnipart/bin/python
for id in 100776 102209 11846 7128; do
  OUT=$C/omnipart/$id; ls $OUT/combined_parts.glb >/dev/null 2>&1 && { echo "$id done"; continue; }
  echo "=== [$(date +%T)] OmniPart $id ==="
  $PY -u $C/omnipart_tex.py --image $C/input/$id.jpg --out $OUT --size_th 1600 --merge "" --seed 42 2>&1 | grep -vaE "Warning|warn|it/s\]" | tail -8
done
echo OMNIPART_TEX_DONE
