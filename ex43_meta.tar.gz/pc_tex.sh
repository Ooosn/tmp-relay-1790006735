#!/bin/bash
T=/liuhaohan/work/single_image_tests/tex_exp/partcrafter; mkdir -p $T
IN=/liuhaohan/work/single_image_tests/tex_exp/input
SCRIPT=/liuhaohan/work/single_image_tests/partcrafter/inference_partcrafter_local.py
[ -f "$SCRIPT" ] || { P=/liuhaohan/repos/PartCrafter; sed -e 's|partcrafter_weights_dir = .*|partcrafter_weights_dir = "/liuhaohan/models/PartCrafter"|' -e 's|rmbg_weights_dir = .*|rmbg_weights_dir = "/liuhaohan/repos/SPARK/pretrained_weights/RMBG-1.4"|' -e '/snapshot_download(repo_id=/d' $P/scripts/inference_partcrafter.py > "$SCRIPT"; }
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 HF_HOME=/liuhaohan/hf_cache PYTHONPATH=/liuhaohan/repos/PartCrafter
PY=/liuhaohan/miniconda3/envs/spark/bin/python
cd /liuhaohan/repos/PartCrafter
np_for(){ case $1 in 100776) echo 3;; 102209) echo 4;; 11846) echo 3;; 7128) echo 4;; esac; }
for id in 100776 102209 11846 7128; do
  ls $T/results/$id/*.glb >/dev/null 2>&1 && { echo "$id already"; continue; }
  n=$(np_for $id); echo "=== PartCrafter $id np=$n $(date +%T) ==="
  CUDA_VISIBLE_DEVICES=1 $PY -u "$SCRIPT" --image_path $IN/$id.jpg --num_parts $n --rmbg --render --output_dir $T/results --tag $id --seed 0 2>&1 | grep -vaE "Warning|warn|it/s\]" | tail -5
done
echo PARTCRAFTER_TEX_DONE
