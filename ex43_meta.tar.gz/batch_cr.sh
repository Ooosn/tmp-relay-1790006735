#!/bin/bash
C=/liuhaohan/work/single_image_tests/tex_exp; PY=/liuhaohan/miniconda3/envs/spark/bin/python
exec >> $C/batch_render.log 2>&1
echo "===== BATCH_CR $(date) ====="
ids="100776 102209 11846 7128"
for m in partcrafter spark ours; do for id in $ids; do [ -f $C/colored/${m}_${id}.glb ] || $PY $C/colorize_parts.py $m $id; done; done
for id in $ids; do [ -f $C/xpart/$id/xpart/xpart_parts.glb ] && { [ -f $C/colored/xpart_${id}.glb ] || $PY $C/colorize_parts.py xpart $id; }; done
for id in $ids; do [ -f $C/omnipart/$id/combined_parts.glb ] && { [ -f $C/colored/omnipart_${id}.glb ] || $PY $C/colorize_parts.py omnipart $id; }; done
for f in $C/colored/*.glb; do n=$(basename $f .glb); [ -f $C/renders/${n}_L.png ] || $PY $C/render_parts.py $f; done
echo BATCH_CR_DONE
