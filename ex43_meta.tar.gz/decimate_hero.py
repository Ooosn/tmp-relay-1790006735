import trimesh, numpy as np, glob, os, open3d as o3d
IN="/liuhaohan/work/single_image_tests/tex_exp/colored_hero"
OUT="/liuhaohan/work/single_image_tests/tex_exp/colored_hero_dec"; os.makedirs(OUT,exist_ok=True)
def dec_part(m,col,target=8000):
    if len(m.faces)>target:
        om=o3d.geometry.TriangleMesh(o3d.utility.Vector3dVector(np.asarray(m.vertices,np.float64)),o3d.utility.Vector3iVector(np.asarray(m.faces,np.int32)))
        om=om.simplify_quadric_decimation(int(target))
        v=np.asarray(om.vertices);f=np.asarray(om.triangles)
        if len(v)>=3 and len(f)>=1: m=trimesh.Trimesh(vertices=v,faces=f,process=False)
    m.visual=trimesh.visual.ColorVisuals(mesh=m,vertex_colors=np.tile(np.array(col,np.uint8),(len(m.vertices),1)))
    return m
def process(path):
    name=os.path.basename(path)
    if os.path.exists(OUT+"/"+name): print("skip",name); return
    s=trimesh.load(path,force='scene'); geoms=s.dump() if isinstance(s,trimesh.Scene) else [s]
    allv=np.vstack([g.vertices for g in geoms]); c=np.median(allv,0)
    med=np.median(np.linalg.norm(allv-c,axis=1)); thr=max(med*40,1e-3)
    out=[]
    for g in geoms:
        vc=getattr(g.visual,'vertex_colors',None)
        col=(vc[0].tolist() if vc is not None and len(vc)>0 else [180,180,180,255])
        d=np.linalg.norm(g.vertices-c,axis=1); fm=(d<thr)[g.faces].all(axis=1)
        if fm.sum()<1: continue
        g2=g.submesh([np.where(fm)[0]],append=True); out.append(dec_part(g2,col))
    if out: trimesh.Scene(out).export(OUT+"/"+name); print("OK",name,"parts",len(out))
    else: print("EMPTY",name)
for p in sorted(glob.glob(IN+"/*.glb")):
    try: process(p)
    except Exception as e: print("ERR",os.path.basename(p),repr(e)[:70])
print("DECIMATE_DONE")
