import os,sys,types,argparse,glob,shutil
os.environ["OPENCV_IO_ENABLE_OPENEXR"]="1"; os.environ["SPCONV_ALGO"]="native"; os.environ.setdefault("HF_HOME","/liuhaohan/.cache/huggingface")
_sp=types.ModuleType("spaces")
def _GPU(*a,**k):
    if len(a)==1 and callable(a[0]) and not k: return a[0]
    def deco(f): return f
    return deco
_sp.GPU=_GPU; sys.modules["spaces"]=_sp
_gr=types.ModuleType("gradio")
class _Request:
    def __init__(self,session_hash="cli"): self.session_hash=session_hash
_gr.Request=_Request; sys.modules["gradio"]=_gr
from huggingface_hub import hf_hub_download
import sys as _s; _s.path.insert(0,"/liuhaohan/repos/OmniPart"); import app_utils as A
from transformers import AutoModelForImageSegmentation
_rmbg=AutoModelForImageSegmentation.from_pretrained("/liuhaohan/models/RMBG-2.0",trust_remote_code=True,local_files_only=True); _rmbg.to("cuda").eval(); A.rmbg_model=_rmbg
ap=argparse.ArgumentParser()
ap.add_argument("--image",required=True); ap.add_argument("--out",required=True); ap.add_argument("--size_th",type=int,default=1600); ap.add_argument("--merge",default=""); ap.add_argument("--seed",type=int,default=42); ap.add_argument("--cfg",type=float,default=7.5)
a=ap.parse_args(); os.makedirs(a.out,exist_ok=True)
ck="ckpt"; os.makedirs(ck,exist_ok=True)
sam="/liuhaohan/repos/OmniPart/ckpt/sam_vit_h_4b8939.pth"
pf="/liuhaohan/repos/OmniPart/ckpt/partfield_encoder.ckpt"
bb="/liuhaohan/repos/OmniPart/ckpt/bbox_gen.ckpt"
A.prepare_models(sam,pf,bb)
req=_Request("cli")
init_seg,pre_merge,state=A.process_image(a.image,a.size_th,req)
try:
    from PIL import Image; import numpy as np
    (init_seg if hasattr(init_seg,"save") else Image.fromarray(np.asarray(init_seg).astype("uint8"))).save(os.path.join(a.out,"numbered.png")); print("saved numbered.png")
except Exception as e: print("numbered save fail",repr(e))
try: merged_seg,state=A.apply_merge(a.merge,state,req)
except Exception as e: print("merge fail",repr(e)); merged_seg,state=A.apply_merge("",state,req)
outputs=A.generate_parts(state,a.seed,a.cfg,req)
names=["bbox_mesh","combined_parts","exploded_parts","combined_gaussians","exploded_gaussians"]
if isinstance(outputs,(list,tuple)):
    for n,o in zip(names,outputs):
        print(n,"->",o)
        if isinstance(o,str) and os.path.isfile(o) and o.endswith(".glb"): shutil.copy(o,os.path.join(a.out,n+".glb"))
try:
    for f in glob.glob(os.path.join(A.TMP_ROOT,"cli","*.glb")): shutil.copy(f,os.path.join(a.out,os.path.basename(f)))
except Exception as e: print("tmp copy",repr(e))
print("OMNIPART_ONE_OK")
