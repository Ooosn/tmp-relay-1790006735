#!/bin/bash
C=/liuhaohan/work/single_image_tests/tex_exp; PY=/liuhaohan/miniconda3/envs/spark/bin/python
exec >> $C/batch_hero.log 2>&1
echo "===== BATCH_HERO $(date) ====="
for m in partcrafter omnipart spark xpart ours; do
  for id in 100776 102209 11846 7128; do
    [ -f $C/colored_hero/${m}_${id}_whole.glb ] || $PY $C/colorize_hero.py $m $id
    for mode in whole exploded; do
      [ -f $C/renders/${m}_${id}_${mode}_L.png ] || $PY $C/render_parts.py $C/colored_hero/${m}_${id}_${mode}.glb 2>&1 | tail -1
    done
  done
done
echo BATCH_HERO_DONE
