#!/bin/bash
source /liuhaohan/miniconda3/etc/profile.d/conda.sh; conda activate trellis2
cd /liuhaohan/repos/TRELLIS.2; export PYTHONPATH=/liuhaohan/repos/TRELLIS.2:$PYTHONPATH CUDA_VISIBLE_DEVICES=1
python -u /liuhaohan/work/single_image_tests/tex_exp/trellis_runner.py
