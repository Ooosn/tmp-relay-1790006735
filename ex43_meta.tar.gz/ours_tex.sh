#!/bin/bash
C=/liuhaohan/work/single_image_tests/tex_exp; T=$C/trellis2
exec >> $C/ours_tex.log 2>&1
echo "===== OURS (particulate) $(date) ====="
for i in $(seq 1 300); do grep -q TRELLIS_TEX_DONE $C/trellis_tex.log 2>/dev/null && break; sleep 30; done
PF=/liuhaohan/miniconda3/envs/partfield/bin/python
export CUDA_VISIBLE_DEVICES=0 PYTHONPATH=/liuhaohan/repos/particulate
cd /liuhaohan/repos/particulate
for id in 100776 102209 11846 7128; do
  GLB=$T/$id.glb; OUT=$C/ours/$id
  [ -f $GLB ] || { echo "no mesh $id"; continue; }
  [ -f $OUT/mesh_parts_with_axes.glb ] && { echo "$id done"; continue; }
  mkdir -p $OUT; echo "=== [$(date +%T)] particulate $id ==="
  $PF -u infer.py --input_mesh $GLB --output_dir $OUT --up_dir Y --no_strict 2>&1 | grep -vaE "Warning|warn|it/s\]" | tail -8
done
echo OURS_TEX_DONE
