#!/bin/bash
C=/liuhaohan/work/single_image_tests/tex_exp; T=$C/trellis2
exec >> $C/xpart_tex.log 2>&1
echo "===== P3SAM+XPART $(date) ====="
for i in $(seq 1 400); do grep -q TRELLIS_TEX_DONE $C/trellis_tex.log 2>/dev/null && break; sleep 30; done
ln -sfn /liuhaohan/models/sonata /root/sonata
VP=/liuhaohan/venvs/hunyuan3dpart/bin/python
export HF_ENDPOINT=https://hf-mirror.com CUDA_VISIBLE_DEVICES=1 PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
for i in $(seq 1 160); do used=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits | sed -n '2p'); [ "$used" -lt 35000 ] && break; echo "wait gpu1 ($used)"; sleep 30; done
for id in 100776 102209 11846 7128; do
  GLB=$T/$id.glb; W=$C/xpart/$id
  [ -f $GLB ] || { echo "no mesh $id"; continue; }
  [ -f $W/xpart/xpart_parts.glb ] && { echo "$id done"; continue; }
  mkdir -p $W
  echo "=== [$(date +%T)] P3-SAM $id ==="
  cd /liuhaohan/repos/Hunyuan3D-Part/P3-SAM/demo
  $VP -u auto_mask.py --ckpt_path /liuhaohan/models/Hunyuan3D-Part/p3sam/p3sam.safetensors --mesh_path $GLB --output_path $W/p3sam --save_mid_res 1 --parallel 0 --seed 42 2>&1 | grep -vaE "Warning|warn|it/s\]" | tail -4
  echo "=== [$(date +%T)] X-Part $id ==="
  sed -e "s|mesh_path='.*'|mesh_path='$GLB'|" -e "s|out=Path('.*')|out=Path('$W/xpart')|" /liuhaohan/lhh/gagent/runs/case0/_run_xpart.py > $W/run_xpart.py
  $VP -u $W/run_xpart.py 2>&1 | grep -vaE "Warning|warn|it/s\]" | tail -5
done
echo XPART_TEX_DONE
