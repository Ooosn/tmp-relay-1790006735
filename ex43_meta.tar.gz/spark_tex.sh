#!/bin/bash
REPO=/liuhaohan/repos/SPARK_official_zju; PY=/liuhaohan/miniconda3/envs/spark/bin/python
export PYTHONPATH=$REPO:/liuhaohan/lhh/gagent USE_TF=0 USE_FLAX=0 TRANSFORMERS_OFFLINE=1 HF_HUB_OFFLINE=1 HF_HUB_DISABLE_TELEMETRY=1 HF_HOME=/liuhaohan/.cache/huggingface
C=/liuhaohan/work/single_image_tests/tex_exp; IN=$C/input; cd $REPO
for id in 100776 102209 11846 7128; do
  CASE=$C/spark/$id; [ -f $CASE/DONE ] && { echo "$id done"; continue; }
  mkdir -p $CASE; [ -f $CASE/input.png ] || $PY -c "from PIL import Image;Image.open('$IN/$id.jpg').convert('RGB').save('$CASE/input.png')"
  echo "=== [$(date +%T)] SPARK $id LLM ==="
  [ -f $CASE/metadata.json ] || $PY VLMguidance/generate_json.py --input $CASE/input.png --output $CASE/metadata.json --csv VLMguidance/partnet-mobility-data-analysis.csv --seed 42 2>&1 | tail -1
  [ -f $CASE/mobility.urdf ] || { $PY VLMguidance/repredict_axis.py --input $CASE --image input.png --single 2>&1 | tail -1; $PY VLMguidance/generate_urdf.py --input-dir $CASE --single 2>&1 | tail -1; }
  [ -f $CASE/prompt_part.json ] || $PY VLMguidance/generate_prompt_part.py --input $CASE 2>&1 | tail -1
  for part in $($PY -c "import json;print(' '.join(json.load(open('$CASE/prompt_part.json'))['prompts'].keys()))" 2>/dev/null); do [ -s $CASE/$part.png ] || $PY VLMguidance/generate_image_part.py --input $CASE --part $part --temperature 1.0 2>&1 | tail -1; done
  ls $CASE/inference/FT5_G1_0/part_*.glb >/dev/null 2>&1 || CUDA_VISIBLE_DEVICES=2 $PY scripts/inference/part_images.py --image_folder $CASE --output_dir $CASE/inference --tag FT5_G1_0 --seed 0 --num_inference_steps 1000 --guidance_scale 1 --render 2>&1 | grep -vaE "it/s\]" | tail -2
  for m in $CASE/inference/FT5_G1_0/part_*.glb; do case "$m" in *_cleaned.glb|*_aligned.glb) continue;; esac; [ -f ${m%.glb}_cleaned.glb ] || $PY src/utils/clean_mesh.py --in_mesh $m --out_mesh ${m%.glb}_cleaned.glb --keep_largest --merge_tol 1e-5 --target_faces 200000 2>&1 | tail -1; done
  cp $CASE/mobility.urdf $CASE/inference/FT5_G1_0/mobility.urdf 2>/dev/null
  { [ -f $CASE/mobility.urdf ] && ls $CASE/inference/FT5_G1_0/*_cleaned.glb >/dev/null 2>&1; } && touch $CASE/DONE; echo "SPARK $id DONE"
done
echo SPARK_TEX_DONE
